# [145. Binary Tree Postorder Traversal](https://leetcode.com/problems/binary-tree-postorder-traversal/)

## 题目


Given a binary tree, return the postorder traversal of its nodes' values.



Example :

```c
Input: [1,null,2,3]
   1
    \
     2
    /
   3

Output: [3,2,1]
```


Follow up: Recursive solution is trivial, could you do it iteratively?


 

## 题目大意

后根遍历一颗树。

## 解题思路

递归的实现方法，见代码。



