---
title: 2.09 Depth First Search
type: docs
weight: 9
---

# Depth First Search


{{.AvailableTagTable}}