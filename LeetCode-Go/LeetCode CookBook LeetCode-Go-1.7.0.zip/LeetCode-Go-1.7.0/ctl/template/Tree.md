---
title: 2.06 Tree
type: docs
weight: 6
---

# Tree


{{.AvailableTagTable}}