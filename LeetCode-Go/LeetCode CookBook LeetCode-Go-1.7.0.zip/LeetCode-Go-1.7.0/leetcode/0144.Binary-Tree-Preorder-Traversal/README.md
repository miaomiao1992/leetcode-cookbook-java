# [144. Binary Tree Preorder Traversal](https://leetcode.com/problems/binary-tree-preorder-traversal/)

## 题目

Given a binary tree, return the preorder traversal of its nodes' values.



Example :

```c
Input: [1,null,2,3]
   1
    \
     2
    /
   3

Output: [1,2,3]
```


Follow up: Recursive solution is trivial, could you do it iteratively?


 

## 题目大意

先根遍历一颗树。

## 解题思路

两种递归的实现方法，见代码。



