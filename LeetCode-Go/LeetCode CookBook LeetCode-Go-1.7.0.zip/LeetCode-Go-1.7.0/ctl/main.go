package main

func main() {
	execute()
}
