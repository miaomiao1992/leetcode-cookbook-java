---
title: 2.14 ✅ Sort
type: docs
weight: 14
---

# Sort

![](https://img.halfrost.com/Leetcode/Sort.png)

- 深刻的理解多路快排。第 75 题。
- 链表的排序，插入排序(第 147 题)和归并排序(第 148 题)
- 桶排序和基数排序。第 164 题。
- "摆动排序"。第 324 题。
- 两两不相邻的排序。第 767 题，第 1054 题。
- "饼子排序"。第 969 题。


{{.AvailableTagTable}}