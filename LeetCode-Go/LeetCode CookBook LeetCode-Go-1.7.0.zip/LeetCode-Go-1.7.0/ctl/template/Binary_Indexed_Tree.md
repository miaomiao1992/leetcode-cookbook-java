---
title: 2.19 ✅ Binary Indexed Tree
type: docs
weight: 19
---

# Binary Indexed Tree

![](https://img.halfrost.com/Leetcode/Binary_Indexed_Tree.png)

{{.AvailableTagTable}}