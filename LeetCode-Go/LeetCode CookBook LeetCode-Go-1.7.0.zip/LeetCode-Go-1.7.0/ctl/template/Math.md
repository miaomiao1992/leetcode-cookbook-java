---
title: 2.12 Math
type: docs
weight: 12
---

# Math


{{.AvailableTagTable}}